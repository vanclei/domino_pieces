from cryosparc.tools import CryoSPARC

cs = CryoSPARC(host="cryoem0.sbi", base_port=40000)
assert cs.test_connection()    
assert cs.cli.hello_world() == {"hello": "world"}  # type: ignore
